<?php
	phpinfo();