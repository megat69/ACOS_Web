<?php
	require 'lang_select.php';
	
	header('Location: main/');