![Discord](https://img.shields.io/discord/718802975153324093?label=Discord%20server) ![GitHub repo size](https://img.shields.io/github/repo-size/megat69/ACOS?label=Repository%20size) ![GitHub release (latest by date)](https://img.shields.io/github/v/release/megat69/ACOS?label=Last%20release) ![OS Support](https://img.shields.io/badge/OS%20Support-Windows%2C%20Mac%2C%20Linux-brightgreen)

# ACOS
An online operating system, made for fun ;) !

You can use it as you wish.
**[Use it at this link ;\) !](http://matrobot.free.fr/acos-remastered/)**

# Features
ACOS works with cookies and apps.

## Apps
### BuildIt!
This system app allow you to customize your ACOS ! Change the theme or the language *(translations soon)* !

### TextRock
A simple plain text editor, that allows you to edit text, save it, and download it.

You can now also open from a text file.

# APIs
Soon !

# Changelogs
## Alpha0.6
- Textrock
* Added an "open from txt" option
- Backend changes


# APIs
Soon !
