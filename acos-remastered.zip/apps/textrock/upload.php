<script>
	const input('')
</script>