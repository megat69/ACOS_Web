<?php
	header('Location: https://startpage.com/'.$Lang);