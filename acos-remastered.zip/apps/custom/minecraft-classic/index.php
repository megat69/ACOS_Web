<?php
	header('Location: https://classic.minecraft.net');