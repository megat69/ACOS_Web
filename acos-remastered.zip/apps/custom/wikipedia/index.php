<?php
	$home_path = '../../../';
	require $home_path.'lang_select.php';
	header('Location: https://'.$Lang.'.wikipedia.org');