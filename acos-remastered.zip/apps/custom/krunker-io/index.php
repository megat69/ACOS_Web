<?php
	header('Location: https://krunker.io');