<?php
	header('Location: https://www.crazygames.com/embed/bullet-force-multiplayer');
